<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $marks = $_POST['marks'];

    // Check if the student already exists
    $query = "SELECT * FROM students WHERE name = ? AND subject = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $name, $subject);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Student exists, update marks
        $student = $result->fetch_assoc();
        $new_marks = $student['marks'] + $marks;
        $conn->query("UPDATE students SET marks = $new_marks WHERE id = " . $student['id']);
    } else {
        // Student does not exist, insert new
        $conn->query("INSERT INTO students (name, subject, marks) VALUES ('$name', '$subject', '$marks')");
    }

    header("Location: home.php");
}
?>
