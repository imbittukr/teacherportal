<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the student ID from the form submission
    $student_id = $_POST['student_id'];

    // Prepare the DELETE SQL query
    $query = "DELETE FROM students WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $student_id);  // Bind the student ID to the query

    // Execute the query
    if ($stmt->execute()) {
        // Redirect back to the home page after deletion
        header("Location: home.php");
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
