<?php
session_start();
if (!isset($_SESSION['teacher'])) {
    header("Location: login.php");
    exit;
}

require 'db.php';  // Database connection

// Fetch students
$query = "SELECT * FROM students";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Teacher Portal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
    #dropdownMenu2{
        border-radius:20px;
    }
    #dropdownMenu2::after {
    display: none;
}
</style>
</head>

<body>

    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light mt-5 mb-3">
            <a class="navbar-brand text-danger">tailwebs.</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                        <a class="nav-link" href="#">Home</a> <!-- Logout link -->
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a> <!-- Logout link -->
                    </li>
                </ul>
            </div>
        </nav>
        <h4>Welcome, <?php echo $_SESSION['teacher']; ?></h4>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Subject</th>
                    <th>Marks</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="student-list">
                <?php while ($row = $result->fetch_assoc()) { ?>
                <tr id="student-<?php echo $row['id']; ?>">
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['subject']; ?></td>
                    <td><?php echo $row['marks']; ?></td>
                    <td>
                    <div class="dropdown">
    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2"
        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fa fa-chevron-circle-down" aria-hidden="true"></i>
    </button>
    <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
        <button class="dropdown-item edit-button" data-id="<?php echo $row['id']; ?>"
            data-name="<?php echo $row['name']; ?>"
            data-subject="<?php echo $row['subject']; ?>"
            data-marks="<?php echo $row['marks']; ?>" data-toggle="modal"
            data-target="#editModal">Edit</button>
        <form method="post" action="delete_student.php" style="display:inline-block;">
            <input type="hidden" name="student_id" value="<?php echo $row['id']; ?>">
            <button class="dropdown-item" type="submit">Delete</button>
        </form>
    </div>
</div>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        <button class="btn btn-dark" data-toggle="modal" data-target="#addModal">Add New Student</button>

        <!-- Modal for Adding Student -->
        <div class="modal" id="addModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="post" action="add_student.php">
                        <div class="modal-header">
                            <h4 class="modal-title">Add Student</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Name:</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Subject:</label>
                                <input type="text" name="subject" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Marks:</label>
                                <input type="number" name="marks" class="form-control" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-dark">Add</button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal for Editing Student -->
        <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit Student</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="editStudentForm">
                <div class="modal-body">
                    <input type="hidden" name="id" id="edit-student-id">
                    <div class="form-group">
                        <label for="edit-name">Name</label>
                        <input type="text" class="form-control" id="edit-name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-subject">Subject</label>
                        <input type="text" class="form-control" id="edit-subject" name="subject" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-marks">Marks</label>
                        <input type="number" class="form-control" id="edit-marks" name="marks" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
    </div>

    <script>
    $(document).ready(function() {
        // Open the modal and populate it with data
        $('.btn-edit').click(function() {
            var id = $(this).data('id');
            var name = $(this).data('name');
            var subject = $(this).data('subject');
            var marks = $(this).data('marks');

            $('#edit-id').val(id);
            $('#edit-name').val(name);
            $('#edit-subject').val(subject);
            $('#edit-marks').val(marks);
        });

        // Handle the form submission for editing the student
        // $('#editStudentForm').submit(function(e) {
        //     e.preventDefault();

        //     $.ajax({
        //         url: 'edit_student.php',
        //         type: 'POST',
        //         data: $(this).serialize(),
        //         success: function(response) {
        //             alert('Student updated successfully');
        //             location.reload(); // Reload the page to reflect changes
        //         },
        //         error: function() {
        //             alert('An error occurred while updating the student details');
        //         }
        //     });
        // });
        $('.edit-button').on('click', function() {
        // Get the student data from the button's data attributes
        var studentId = $(this).data('id');
        var studentName = $(this).data('name');
        var studentSubject = $(this).data('subject');
        var studentMarks = $(this).data('marks');

        // Populate the modal fields with the existing data
        $('#edit-student-id').val(studentId);
        $('#edit-name').val(studentName);
        $('#edit-subject').val(studentSubject);
        $('#edit-marks').val(studentMarks);
        
        // Open the modal
        $('#editModal').modal('show');
    });

    // Handle the form submission for editing the student
    $('#editStudentForm').submit(function(e) {
        e.preventDefault();

        $.ajax({
            url: 'edit_student.php',
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response === 'success') {
                    alert('Student updated successfully');
                    location.reload(); // Reload the page to reflect changes
                } else {
                    alert('An error occurred while updating the student details');
                }
            },
            error: function() {
                alert('An error occurred while updating the student details');
            }
        });
    });
    });
   
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>